// Recherche fédérée : AniList + MyAnimeList (via Jikan) + Kitsu, fusionnées sans doublons.
(function (root) {
  "use strict";
  const ANI = "https://graphql.anilist.co", JIK = "https://api.jikan.moe/v4/anime", KIT = "https://kitsu.app/api/edge/anime";
  const PRIO = { AniList: 0, MyAnimeList: 1, Kitsu: 2 };
  const nrm = (s) => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const first = (x, y) => (x != null && x !== "" ? x : y);
  const JG = { Action: 1, Adventure: 2, Comedy: 4, Drama: 8, Ecchi: 9, Fantasy: 10, Horror: 14, Mecha: 18, Music: 19, Mystery: 7, Psychological: 40, Romance: 22, "Sci-Fi": 24, "Slice of Life": 36, Sports: 30, Supernatural: 37, Thriller: 41 };
  const KG = { Action: "action", Adventure: "adventure", Comedy: "comedy", Drama: "drama", Ecchi: "ecchi", Fantasy: "fantasy", Horror: "horror", Mecha: "mecha", Music: "music", Mystery: "mystery", Psychological: "psychological", Romance: "romance", "Sci-Fi": "science-fiction", "Slice of Life": "slice-of-life", Sports: "sports", Supernatural: "supernatural", Thriller: "thriller" };
  const GC = { "science fiction": "Sci-Fi", "sci fi": "Sci-Fi", suspense: "Thriller" };
  const cg = (g) => GC[String(g).toLowerCase()] || g;

  async function getJSON(url, opt = {}, tries = 2) {
    let err;
    for (let i = 0; i < tries; i++) {
      const ac = new AbortController(), to = setTimeout(() => ac.abort(), 12000);
      try {
        const r = await fetch(url, { ...opt, signal: ac.signal });
        clearTimeout(to);
        if (r.status === 429 || r.status >= 500) { err = new Error("HTTP " + r.status); await sleep(900 * (i + 1)); continue; }
        if (!r.ok) throw Object.assign(new Error("HTTP " + r.status), { fatal: true });
        return await r.json();
      } catch (e) {
        clearTimeout(to); if (e.fatal) throw e;
        err = e.name === "AbortError" ? new Error("délai dépassé") : e; await sleep(500 * (i + 1));
      }
    }
    throw err;
  }

  const AQ = `query($p:Int,$s:String,$g:[String],$y:Int,$f:MediaFormat,$m:Int,$o:[MediaSort]){Page(page:$p,perPage:30){pageInfo{hasNextPage}media(type:ANIME,isAdult:false,search:$s,genre_in:$g,seasonYear:$y,format:$f,averageScore_greater:$m,sort:$o){id idMal title{romaji english}coverImage{large color}description(asHtml:false)genres episodes duration trailer{id site} seasonYear averageScore format}}}`;
  async function aniFetch(p) {
    const v = { p: p.page, o: [p.sort] };
    if (p.q) v.s = p.q; if (p.genres.length) v.g = p.genres; if (p.yr) v.y = +p.yr; if (p.fmt) v.f = p.fmt; if (p.min) v.m = +p.min;
    const j = await getJSON(ANI, { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ query: AQ, variables: v }) });
    if (j.errors) throw new Error(j.errors[0].message);
    const P = j.data.Page;
    return { hasMore: !!P.pageInfo.hasNextPage, items: P.media.map((m) => ({
      ids: { al: m.id, mal: m.idMal || null }, title: { romaji: m.title.romaji, english: m.title.english },
      coverImage: { large: (m.coverImage && m.coverImage.large) || "", color: (m.coverImage && m.coverImage.color) || "" },
      description: m.description || "", genres: (m.genres || []).map(cg).filter((g) => g !== "Hentai"),
      episodes: m.episodes, duration: m.duration, trailer: m.trailer, seasonYear: m.seasonYear, averageScore: m.averageScore, format: m.format, src: ["AniList"] })) };
  }
  async function jikFetch(p) {
    const gs = p.genres.map((g) => JG[g]); if (gs.some((x) => !x)) return null;
    const q = new URLSearchParams({ page: p.page, limit: 25, sfw: "true" });
    if (p.q) q.set("q", p.q);
    const so = { SCORE_DESC: ["score", "desc"], POPULARITY_DESC: ["popularity", "asc"], START_DATE_DESC: ["start_date", "desc"], TITLE_ROMAJI: ["title", "asc"] }[p.sort];
    if (so) { q.set("order_by", so[0]); q.set("sort", so[1]); }
    if (gs.length) q.set("genres", gs.join(","));
    if (p.fmt) q.set("type", { TV: "tv", MOVIE: "movie", OVA: "ova", ONA: "ona" }[p.fmt]);
    if (p.yr) { q.set("start_date", p.yr + "-01-01"); q.set("end_date", p.yr + "-12-31"); }
    if (p.min) q.set("min_score", String(p.min / 10));
    const j = await getJSON(JIK + "?" + q);
    return { hasMore: !!(j.pagination && j.pagination.has_next_page), items: (j.data || []).map((d) => ({
      ids: { mal: d.mal_id }, title: { romaji: d.title, english: d.title_english },
      coverImage: { large: (d.images && d.images.jpg && (d.images.jpg.large_image_url || d.images.jpg.image_url)) || "", color: "" },
      description: String(d.synopsis || "").replace(/\s*\[Written by[^\]]*\]\s*$/i, ""),
      genres: [...(d.genres || []), ...(d.themes || []), ...(d.demographics || [])].map((x) => cg(x.name)),
      episodes: d.episodes, duration: parseInt(d.duration) || null, trailer: d.trailer && d.trailer.youtube_id ? { site: "youtube", id: d.trailer.youtube_id } : null,
      seasonYear: d.year || (d.aired && d.aired.prop && d.aired.prop.from && d.aired.prop.from.year) || null,
      averageScore: d.score ? Math.round(d.score * 10) : null,
      format: { TV: "TV", Movie: "MOVIE", OVA: "OVA", ONA: "ONA" }[d.type] || (d.type ? String(d.type).toUpperCase() : null), src: ["MyAnimeList"] })) };
  }
  async function kitFetch(p) {
    const cs = p.genres.map((g) => KG[g]); if (cs.some((x) => !x)) return null;
    const q = new URLSearchParams();
    q.set("page[limit]", "20"); q.set("page[offset]", String((p.page - 1) * 20)); q.set("include", "categories,mappings");
    const so = { SCORE_DESC: "-averageRating", POPULARITY_DESC: "popularityRank", START_DATE_DESC: "-startDate", TITLE_ROMAJI: "canonicalTitle" }[p.sort];
    if (p.q) q.set("filter[text]", p.q); else if (so) q.set("sort", so);
    if (cs.length) q.set("filter[categories]", cs.join(","));
    if (p.fmt) q.set("filter[subtype]", { TV: "TV", MOVIE: "movie", OVA: "OVA", ONA: "ONA" }[p.fmt]);
    if (p.yr) q.set("filter[seasonYear]", p.yr);
    if (p.min) q.set("filter[averageRating]", p.min + "..100");
    const j = await getJSON(KIT + "?" + q, { headers: { Accept: "application/vnd.api+json" } });
    const inc = {}; (j.included || []).forEach((x) => (inc[x.type + ":" + x.id] = x));
    const rel = (d, n) => ((d.relationships && d.relationships[n] && d.relationships[n].data) || []).map((r) => inc[r.type + ":" + r.id]).filter(Boolean);
    return { hasMore: !!(j.links && j.links.next), items: (j.data || []).filter((d) => !d.attributes.nsfw).map((d) => {
      const a = d.attributes, t = a.titles || {}, mp = rel(d, "mappings").find((m) => m.attributes && m.attributes.externalSite === "myanimelist/anime");
      const pi = a.posterImage || {};
      return { ids: { kitsu: d.id, mal: mp ? +mp.attributes.externalId || null : null }, title: { romaji: first(t.en_jp, a.canonicalTitle), english: first(t.en, t.en_us) },
        coverImage: { large: pi.large || pi.original || pi.medium || "", color: "" }, description: a.synopsis || "",
        genres: rel(d, "categories").map((c) => cg(c.attributes.title)), episodes: a.episodeCount, duration: a.episodeLength,
        trailer: a.youtubeVideoId ? { site: "youtube", id: a.youtubeVideoId } : null, seasonYear: a.startDate ? +String(a.startDate).slice(0, 4) : null,
        averageScore: a.averageRating ? Math.round(+a.averageRating) : null,
        format: { TV: "TV", movie: "MOVIE", OVA: "OVA", ONA: "ONA", special: "SPECIAL", music: "MUSIC" }[a.subtype] || (a.subtype ? String(a.subtype).toUpperCase() : null), src: ["Kitsu"] };
    }) };
  }

  function fin(a) {
    if (!a.title.romaji && !a.title.english) a.title.romaji = "Sans titre";
    a.genres = [...new Set(a.genres || [])]; a.alt = [...new Set((a.alt || []).filter(Boolean))];
    a.sc = {}; if (a.averageScore) a.sc[a.src[0]] = a.averageScore;
    a.id = a.ids.al ? "a" + a.ids.al : a.ids.mal ? "m" + a.ids.mal : "k" + a.ids.kitsu;
    return a;
  }
  function merge(m, a) {
    const hi = PRIO[a.src[0]] < PRIO[m.src[0]] ? a : m, lo = hi === a ? m : a;
    for (const k of Object.keys(a.ids)) if (!m.ids[k]) m.ids[k] = a.ids[k];
    m.title = { romaji: first(hi.title.romaji, lo.title.romaji), english: first(hi.title.english, lo.title.english) };
    m.coverImage = { large: first(hi.coverImage.large, lo.coverImage.large), color: first(hi.coverImage.color, lo.coverImage.color) };
    m.description = first(hi.description, lo.description);
    m.genres = [...new Set([...hi.genres, ...lo.genres])];
    for (const f of ["episodes", "duration", "trailer", "seasonYear", "format"]) m[f] = first(hi[f], lo[f]);
    m.alt = [...new Set([...(m.alt || []), ...(a.alt || []), a.title.romaji, a.title.english].filter(Boolean))];
    m.src = [...new Set([...m.src, ...a.src])].sort((x, y) => PRIO[x] - PRIO[y]);
    if (a.averageScore) m.sc[a.src[0]] = a.averageScore;
    const v = Object.values(m.sc); m.averageScore = v.length ? Math.round(v.reduce((x, y) => x + y, 0) / v.length) : null;
    m.rk = Math.min(m.rk ?? 1e9, a.rk ?? 1e9);
  }
  function createIndex() {
    const byId = new Map(), byT = new Map();
    const idk = (a) => [a.ids.al && "a" + a.ids.al, a.ids.mal && "m" + a.ids.mal, a.ids.kitsu && "k" + a.ids.kitsu].filter(Boolean);
    const tk = (a) => [...new Set([a.title.romaji, a.title.english, ...(a.alt || [])].map(nrm).filter((n) => n.length >= 3))];
    const reg = (a) => { idk(a).forEach((k) => byId.set(k, a)); tk(a).forEach((t) => { const l = byT.get(t) || []; if (!l.includes(a)) l.push(a); byT.set(t, l); }); };
    const same = (a, b) => {
      if (a.ids.mal && b.ids.mal && a.ids.mal !== b.ids.mal) return false;
      if (a.ids.al && b.ids.al && a.ids.al !== b.ids.al) return false;
      if (a.seasonYear && b.seasonYear && Math.abs(a.seasonYear - b.seasonYear) > 1) return false;
      if (a.format && b.format && (a.format === "MOVIE") !== (b.format === "MOVIE")) return false;
      return true;
    };
    const find = (a) => {
      for (const k of idk(a)) { const x = byId.get(k); if (x) return x; }
      for (const t of tk(a)) for (const x of byT.get(t) || []) if (same(a, x)) return x;
      return null;
    };
    return {
      add(a) { const m = find(a); if (m) { merge(m, a); reg(m); return { item: m, isNew: false }; } fin(a); reg(a); return { item: a, isNew: true }; },
      clear() { byId.clear(); byT.clear(); },
    };
  }

  async function search(p, idx) {
    const jobs = [["AniList", aniFetch], ["MyAnimeList", jikFetch], ["Kitsu", kitFetch]];
    const res = await Promise.allSettled(jobs.map(([, f]) => f(p)));
    const failed = [], out = []; let hasMore = false;
    res.forEach((r, i) => {
      if (r.status === "rejected") { failed.push(jobs[i][0]); return; }
      if (!r.value) return;
      hasMore = hasMore || r.value.hasMore;
      r.value.items.forEach((a, rank) => {
        if (p.genres.length && !p.genres.every((g) => a.genres.includes(g))) return;
        a.rk = rank; const x = idx.add(a); if (x.isNew) out.push(x.item);
      });
    });
    const s = p.sort;
    out.sort(s === "SCORE_DESC" ? (a, b) => (b.averageScore || 0) - (a.averageScore || 0)
      : s === "START_DATE_DESC" ? (a, b) => (b.seasonYear || 0) - (a.seasonYear || 0)
      : s === "TITLE_ROMAJI" ? (a, b) => String(a.title.romaji || a.title.english).localeCompare(String(b.title.romaji || b.title.english))
      : (a, b) => a.rk - b.rk);
    return { items: out, failed, hasMore };
  }
  async function lookup(t) {
    const p = { q: t, sort: "SEARCH_MATCH", genres: [], page: 1, fmt: "", yr: "", min: "" };
    let answered = 0, err;
    for (const f of [aniFetch, jikFetch, kitFetch]) {
      try {
        const r = await f(p); answered++;
        if (r && r.items.length) {
          const n = nrm(t), best = r.items.find((a) => [a.title.romaji, a.title.english].map(nrm).includes(n)) || r.items[0];
          return createIndex().add(best).item;
        }
      } catch (e) { err = e; }
      await sleep(250);
    }
    if (!answered) throw err || new Error("Aucune source n’a répondu.");
    return null;
  }
  const api = { search, lookup, createIndex };
  root.Sources = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
