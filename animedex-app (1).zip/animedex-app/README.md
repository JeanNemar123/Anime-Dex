# AnimeDex

Catalogue d’animés (AniList, MyAnimeList via Jikan et Kitsu, fusionnés sans doublons) avec favoris, vus, « à regarder », progression des épisodes, statistiques, bandes-annonces, **comptes (pseudo + mot de passe)** et **synchronisation entre appareils**. Installable sur téléphone (PWA).

## Lancer en local
Node 22.13 ou plus récent, aucune dépendance à installer :

    node server.js

Puis ouvre http://localhost:3000. Les comptes sont stockés dans `data/animedex.db` (SQLite).

## Mettre en ligne
Le serveur a besoin d’un **stockage persistant** pour `DB_PATH` (par défaut `/data/animedex.db` dans Docker) et d’**HTTPS** (fourni par la plupart des hébergeurs). Options : Fly.io (volume), Railway (volume), Render (disque payant), ou un VPS avec Docker.

    docker build -t animedex .
    docker run -p 3000:3000 -v animedex-data:/data animedex

Variables : `PORT` (3000), `DB_PATH`, `TRUST_PROXY=1` si le serveur est derrière un proxy (pour limiter les tentatives de connexion par IP réelle).

## GitHub
Le workflow `.github/workflows/docker.yml` vérifie le code puis publie l’image Docker sur `ghcr.io/<ton-compte>/<repo>:latest` à chaque push sur `main`. Ton hébergeur peut ensuite la déployer.

## Fabriquer l’APK (Android)
1. Pousse le projet sur GitHub.
2. Onglet **Actions** → workflow **Build APK** (liste de gauche) → bouton **Run workflow**.
3. Quand le run est vert (✓), ouvre-le et télécharge `animedex-apk` dans la section **Artifacts** en bas de page, dézippe, puis installe `app-debug.apk` sur ton téléphone (autorise l’installation d’apps inconnues).

L’adresse du serveur de comptes est écrite dans `public/app.js` (constante `SERVER`). Il doit être en **HTTPS**. Par défaut il accepte toutes les origines (variable `CORS_ORIGINS` pour les restreindre). L’APK produit est un APK de test (« debug ») : parfait pour un usage perso, mais pas publiable sur le Play Store tel quel.

## Installer sur téléphone (sans APK)
Ouvre le site en HTTPS dans Chrome (Android) ou Safari (iOS) puis « Ajouter à l’écran d’accueil ».

## Sécurité et limites
- Mots de passe hachés avec scrypt et sel ; sessions de 90 jours ; 20 tentatives de connexion par 10 minutes et par IP.
- Aucune récupération de mot de passe (pas d’e-mail). Sauvegarde le fichier de base de données.
- Synchronisation : le serveur garde la dernière version ; en cas de modifications simultanées sur deux appareils, les listes sont fusionnées (une suppression faite en même temps peut réapparaître).
- Les données d’animés viennent d’AniList : respecte leurs conditions d’utilisation si tu rends le site public.
