const API="https://graphql.anilist.co",$=id=>document.getElementById(id),sleep=ms=>new Promise(r=>setTimeout(r,ms));
const S=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k));return v==null?d:v}catch(e){return d}};
const W=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}if(k==="lib"&&typeof onLibChange==="function")onLibChange()};
let lib=S("lib",{fav:{},seen:{},hist:[]}),pr=S("prefs",{}),trc=S("trc",{});lib.todo=lib.todo||{};lib.prog=lib.prog||{};lib=migrate(lib);
let gsel=new Set(pr.g||[]),page=1,seq=0,timer,hasMore=false,tab="cat";const items=new Map();
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const mini=a=>({id:a.id,ids:a.ids,src:a.src,title:a.title,coverImage:a.coverImage,description:a.description,genres:a.genres,episodes:a.episodes,duration:a.duration,trailer:a.trailer,seasonYear:a.seasonYear,averageScore:a.averageScore,format:a.format});
const bd=id=>(lib.fav[id]?"♥":"")+(lib.seen[id]?"✓":"")+(lib.todo[id]?"🔖":"");
const name=a=>a.title.english||a.title.romaji;
const card=a=>`<div class="card${lib.seen[a.id]?" seen":""}" data-i="${a.id}"><img loading="lazy" src="${esc((a.coverImage&&a.coverImage.large)||PH)}" alt="" style="background:${esc((a.coverImage&&a.coverImage.color)||"")}"><span class="bd">${bd(a.id)}</span><div class="inf"><b>${esc(name(a))}</b><span>${a.averageScore?"★ "+(a.averageScore/10).toFixed(1):"—"} · ${a.seasonYear||"?"}</span></div></div>`;
// préférences
for(let y=new Date().getFullYear();y>=1980;y--)$("yr").insertAdjacentHTML("beforeend",`<option>${y}</option>`);
if(pr.q)$("q").value=pr.q;["sort","fmt","yr","min"].forEach(k=>{if(pr[k])$(k).value=pr[k]});$("auto").checked=!!pr.auto;
const sp=()=>W("prefs",{q:$("q").value,sort:$("sort").value,fmt:$("fmt").value,yr:$("yr").value,min:$("min").value,g:[...gsel],auto:$("auto").checked});
// réseau robuste
async function gql(query,variables,tries=3){let err;
for(let i=0;i<tries;i++){
if(!navigator.onLine)throw new Error("Tu es hors ligne. Reconnecte-toi puis réessaie.");
const ac=new AbortController(),to=setTimeout(()=>ac.abort(),12000);
try{const r=await fetch(API,{method:"POST",signal:ac.signal,headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify({query,variables})});clearTimeout(to);
if(r.status===429){const w=Math.min(+r.headers.get("Retry-After")||3,10);$("st").textContent="Trop de requêtes, nouvel essai dans "+w+" s…";err=new Error("Trop de requêtes, réessaie dans un instant.");await sleep(w*1000);continue}
if(r.status>=500){err=new Error("AniList est indisponible (erreur "+r.status+").");await sleep(900*(i+1));continue}
const j=await r.json();if(j.errors){const e=new Error(j.errors[0].message);e.fatal=true;throw e}return j.data}
catch(e){clearTimeout(to);if(e.fatal)throw e;err=e.name==="AbortError"?new Error("Délai dépassé, la connexion est lente."):new Error("Connexion impossible.");await sleep(700*(i+1))}}
throw err}
const Q=`query($p:Int,$s:String,$g:[String],$y:Int,$f:MediaFormat,$m:Int,$o:[MediaSort]){Page(page:$p,perPage:30){pageInfo{hasNextPage}media(type:ANIME,isAdult:false,search:$s,genre_in:$g,seasonYear:$y,format:$f,averageScore_greater:$m,sort:$o){id title{romaji english}coverImage{large color}description(asHtml:false)genres episodes duration trailer{id site} seasonYear averageScore format}}}`;
const PH="data:image/svg+xml,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="300"><rect width="200" height="300" fill="#6c4cf1"/></svg>');
function migrate(l){const fix=o=>{if(!o||typeof o!=="object"||o.ids)return o;return{...o,id:"a"+o.id,ids:{al:o.id},src:["AniList"]}};
const re=m=>{const r={};for(const[k,v]of Object.entries(m||{}))r[/^\d+$/.test(k)?"a"+k:k]=fix(v);return r};
return{fav:re(l.fav),seen:re(l.seen),todo:re(l.todo),prog:re(l.prog),hist:(l.hist||[]).map(fix)}}
const aliases=a=>{const i=a.ids||{};return[a.id,i.al&&"a"+i.al,i.mal&&"m"+i.mal,i.kitsu&&"k"+i.kitsu].filter(Boolean)};
const uniq=list=>{const seen=new Set();return list.filter(a=>{const ks=aliases(a);if(ks.some(k=>seen.has(k)))return false;ks.forEach(k=>seen.add(k));return true})};
function canon(a){let ch=false;
for(const k of["fav","seen","todo","prog"])for(const al of aliases(a)){if(al===a.id||lib[k][al]===undefined)continue;
if(lib[k][a.id]===undefined)lib[k][a.id]=k==="prog"?lib[k][al]:mini(a);else if(k==="prog")lib[k][a.id]=Math.max(lib[k][a.id],lib[k][al]);
delete lib[k][al];ch=true}
if(ch)W("lib",lib)}
const idx=Sources.createIndex();
async function load(reset){
if(reset){page=1;items.clear();idx.clear();$("grid").innerHTML="";sp()}
const me=++seq;$("st").textContent="Chargement…";$("more").hidden=true;
const prm={q:$("q").value.trim(),sort:$("sort").value,fmt:$("fmt").value,yr:$("yr").value,min:$("min").value,genres:[...gsel],page};
try{const r=await Sources.search(prm,idx);if(me!==seq)return;
if(r.failed.length===3)throw new Error("Aucune source ne répond (réseau ou limite de requêtes).");
r.items.forEach(a=>{canon(a);items.set(a.id,a)});
$("grid").insertAdjacentHTML("beforeend",r.items.map(card).join(""));
$("st").textContent=(items.size?"":"Aucun résultat pour ces critères.")+(r.failed.length?" ⚠ Indisponible : "+r.failed.join(", ")+".":"");
hasMore=r.hasMore;$("more").hidden=!hasMore||tab!=="cat"}
catch(e){if(me===seq)$("st").innerHTML=esc(e.message)+' <button class="btn" id="rt">Réessayer</button>'}}
$("st").onclick=e=>{if(e.target.id==="rt")load(page===1)};
addEventListener("online",()=>{if($("rt"))load(page===1)});
$("more").onclick=()=>{page++;load(false)};
["sort","fmt","yr","min"].forEach(id=>$(id).onchange=()=>load(true));
$("auto").onchange=sp;
$("q").oninput=()=>{clearTimeout(timer);timer=setTimeout(()=>load(true),400)};
$("chips").onclick=e=>{const g=e.target.dataset.g;if(!g)return;gsel.has(g)?gsel.delete(g):gsel.add(g);e.target.classList.toggle("on");load(true)};
// bibliothèque
const L={todo:"🔖 À regarder",fav:"♥ Favoris",seen:"✓ Vus",hist:"🕘 Historique"};
function updTabs(){const n={todo:Object.keys(lib.todo).length,fav:Object.keys(lib.fav).length,seen:Object.keys(lib.seen).length,hist:lib.hist.length};
document.querySelectorAll("#tabs [data-t]").forEach(b=>{if(L[b.dataset.t])b.textContent=L[b.dataset.t]+" ("+n[b.dataset.t]+")"})}
function renderLib(){if(tab==="stats")return renderStats();let list=tab==="fav"?Object.values(lib.fav).reverse():tab==="todo"?Object.values(lib.todo).reverse():tab==="seen"?Object.values(lib.seen).reverse():lib.hist;
list=uniq(list);const msg={todo:"Ta liste est vide. Ouvre un animé et touche « À regarder ».",fav:"Aucun favori pour l’instant. Ouvre un animé et touche ♡.",seen:"Aucun animé marqué comme vu.",hist:"Historique vide."}[tab];
$("lib").innerHTML=(tab==="hist"&&list.length?'<button class="btn" id="clr" style="margin-bottom:12px">Vider l’historique</button>':"")+(list.length?'<div class="g">'+list.map(card).join("")+"</div>":`<div style="text-align:center;color:var(--mu);margin:30px">${msg}</div>`)}
function renderStats(){
const seen=Object.values(lib.seen),all={...lib.todo,...lib.fav,...lib.seen};let eps=0,min=0;const gc={},sc=[];
seen.forEach(a=>{const n=a.episodes||1;eps+=n;min+=n*(a.duration||24);(a.genres||[]).forEach(g=>gc[g]=(gc[g]||0)+1);if(a.averageScore)sc.push(a.averageScore)});
Object.entries(lib.prog).forEach(([id,n])=>{if(lib.seen[id])return;const a=all[id]||lib.hist.find(x=>x.id==id);eps+=n;min+=n*((a&&a.duration)||24)});
const top=Object.entries(gc).sort((a,b)=>b[1]-a[1]).slice(0,6),mx=top.length?top[0][1]:1;
const avg=sc.length?(sc.reduce((a,b)=>a+b,0)/sc.length/10).toFixed(1):"—";
const bx=(v,l)=>`<div style="background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:12px;text-align:center"><div style="font-size:22px;font-weight:700">${v}</div><div style="font-size:12px;color:var(--mu)">${l}</div></div>`;
$("lib").innerHTML=`<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px">${bx(seen.length,"animés vus")}${bx(eps,"épisodes regardés")}${bx(Math.round(min/60)+" h","temps estimé")}${bx(avg,"note moyenne (vus)")}${bx(Object.keys(lib.fav).length,"favoris")}${bx(Object.keys(lib.todo).length,"à regarder")}</div><h3>Genres préférés</h3>${top.length?top.map(([g,n])=>`<div style="display:flex;align-items:center;gap:8px;margin:6px 0;font-size:13px"><span style="width:110px">${esc(g)}</span><div style="flex:1;background:var(--bd);border-radius:6px"><div style="width:${n/mx*100}%;background:var(--ac);height:10px;border-radius:6px"></div></div><span>${n}</span></div>`).join(""):'<p style="color:var(--mu)">Marque des animés comme vus pour voir tes genres préférés.</p>'}`}
function refresh(){document.querySelectorAll(".card").forEach(c=>{const id=c.dataset.i;c.classList.toggle("seen",!!lib.seen[id]);c.querySelector(".bd").textContent=bd(id)});updTabs();if(tab!=="cat")renderLib()}
$("tabs").onclick=e=>{const t=e.target.dataset.t;if(!t)return;tab=t;
document.querySelectorAll("#tabs [data-t]").forEach(b=>b.classList.toggle("on",b.dataset.t===t));
const c=t==="cat";$("filters").hidden=!c;$("grid").hidden=!c;$("st").hidden=!c;$("lib").hidden=c;$("more").hidden=!c||!hasMore;if(!c)renderLib()};
// traduction : API intégrée du navigateur si dispo, sinon MyMemory
async function translate(text){
try{if("Translator"in self&&(await Translator.availability({sourceLanguage:"en",targetLanguage:"fr"}))!=="unavailable"){
const t=await Translator.create({sourceLanguage:"en",targetLanguage:"fr"});return await t.translate(text)}}catch(e){}
const sents=text.match(/[^.!?\n]+[.!?]*\s*|\n+/g)||[text],chunks=[];let cur="";
for(let s of sents){while(s.length>450){if(cur){chunks.push(cur);cur=""}chunks.push(s.slice(0,450));s=s.slice(450)}
if((cur+s).length>450){chunks.push(cur);cur=s}else cur+=s}
if(cur)chunks.push(cur);const out=[];
for(const c of chunks){if(!c.trim()){out.push(c);continue}
const r=await fetch("https://api.mymemory.translated.net/get?langpair=en|fr&q="+encodeURIComponent(c));const j=await r.json();
const t=j.responseData&&j.responseData.translatedText;if(!t||j.responseStatus!=200||/MYMEMORY WARNING/i.test(t))throw new Error("quota");out.push(t)}
return out.join("")}
// fiche
function openM(a){canon(a);
lib.hist=[mini(a),...lib.hist.filter(x=>x.id!==a.id)].slice(0,50);W("lib",lib);updTabs();
const raw=(a.description||"").replace(/<br\s*\/?>/gi,"\n").replace(/<[^>]+>/g,"").trim();
const show=t=>{$("syn").innerHTML=esc(t||"Pas de synopsis.").replace(/\n/g,"<br>")};
$("box").innerHTML=`<img src="${esc((a.coverImage&&a.coverImage.large)||PH)}" alt=""><h2 style="margin:0">${esc(name(a))}</h2><span style="color:var(--mu);font-size:13px">${esc(a.title.romaji)}<br>${a.seasonYear||"?"} · ${esc(a.format||"")} · ${a.episodes?a.episodes+" ép.":"? ép."} · ${a.averageScore?"★ "+(a.averageScore/10).toFixed(1):"—"}<br>Sources : ${esc((a.src||[]).join(" · "))}</span><div class="row" style="clear:both"><button class="btn" id="fb"></button><button class="btn" id="tb"></button><button class="btn" id="sb"></button><button class="btn" id="tr">🌐 Traduire en français</button></div><div class="row" id="pg"></div><div class="row"><button class="btn" id="tbtn">▶ Bande-annonce</button></div><div id="tfr"></div><p id="syn"></p><div>${a.genres.map(g=>`<span class="tag">${esc(g)}</span>`).join("")}</div>`;
show(raw);
const fb=$("fb"),sb=$("sb"),tb=$("tb"),b=$("tr"),N=a.episodes||0,pn=()=>lib.prog[a.id]||0;
const lab=()=>{fb.textContent=lib.fav[a.id]?"♥ Favori":"♡ Favori";tb.textContent=lib.todo[a.id]?"🔖 À regarder ✓":"🔖 À regarder";sb.textContent=lib.seen[a.id]?"✓ Vu":"○ Marquer comme vu"};
const drawP=()=>{if(N===1){$("pg").hidden=true;return}$("pg").innerHTML=`<span style="font-size:13px;color:var(--mu)">Progression</span><button class="btn" id="pm">−</button><b>${pn()}${N?" / "+N:""}</b> ép.<button class="btn" id="pp">+</button>`;$("pm").onclick=()=>setP(pn()-1);$("pp").onclick=()=>setP(pn()+1)};
const setP=n=>{n=Math.max(0,N?Math.min(N,n):n);if(n)lib.prog[a.id]=n;else delete lib.prog[a.id];if(n>0)delete lib.todo[a.id];if(N&&n===N)lib.seen[a.id]=mini(a);W("lib",lib);drawP();lab();refresh()};
const tog=k=>{lib[k][a.id]?delete lib[k][a.id]:lib[k][a.id]=mini(a);W("lib",lib);lab();refresh()};
fb.onclick=()=>tog("fav");tb.onclick=()=>tog("todo");sb.onclick=()=>tog("seen");lab();drawP();
const T=a.trailer;
$("tbtn").onclick=()=>{if(T&&T.site==="youtube"&&/^[\w-]{6,15}$/.test(T.id)){$("tfr").innerHTML=`<iframe src="https://www.youtube-nocookie.com/embed/${T.id}" style="width:100%;aspect-ratio:16/9;border:0;border-radius:10px;margin-top:10px" allowfullscreen loading="lazy"></iframe>`;$("tbtn").hidden=true}else if(T&&T.site==="dailymotion"&&/^[\w-]+$/.test(T.id))window.open("https://www.dailymotion.com/video/"+T.id,"_blank","noopener");else window.open("https://www.youtube.com/results?search_query="+encodeURIComponent(name(a)+" bande-annonce"),"_blank","noopener")};
if(!raw)b.hidden=true;else{let on=false;
b.onclick=async()=>{if(on){show(raw);b.textContent="🌐 Traduire en français";on=false;return}
b.disabled=true;b.textContent="Traduction…";
try{let fr=trc[a.id];if(!fr){fr=await translate(raw);trc[a.id]=fr;const k=Object.keys(trc);if(k.length>100)delete trc[k[0]];W("trc",trc)}
show(fr);b.textContent="Voir l’original";on=true}catch(err){b.textContent="Échec (quota ou réseau), réessayer"}
b.disabled=false};
if($("auto").checked)b.click()}
$("md").classList.add("show")}
document.querySelector("main").onclick=e=>{
if(e.target.id==="clr"){lib.hist=[];W("lib",lib);refresh();return}
const c=e.target.closest(".card");if(!c)return;const id=c.dataset.i;
const a=items.get(id)||lib.fav[id]||lib.seen[id]||lib.hist.find(x=>x.id===id);if(a)openM(a)};
$("md").onclick=e=>{if(e.target.id==="md")$("md").classList.remove("show")};
addEventListener("keydown",e=>{if(e.key==="Escape")$("md").classList.remove("show")});
// import d'une liste de titres
const FLD="id title{romaji english}coverImage{large color}description(asHtml:false)genres episodes duration trailer{id site} seasonYear averageScore format";
const IQ=n=>{const r=[...Array(n).keys()];return`query(${r.map(i=>`$s${i}:String`).join(",")}){${r.map(i=>`q${i}:Page(perPage:1){media(type:ANIME,isAdult:false,search:$s${i},sort:SEARCH_MATCH){${FLD}}}`).join(" ")}}`};
function openImport(){
$("box").innerHTML=`<h2 style="margin:0 0 6px">📥 Importer une liste</h2><p style="color:var(--mu);font-size:13px;margin:0 0 8px">Un titre par ligne (la numérotation et les puces sont ignorées). Jusqu’à 100 titres.</p><textarea id="ita" rows="8" placeholder="Death Note&#10;Steins;Gate&#10;Frieren" style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--bd);background:var(--bg)"></textarea><div class="row"><select id="imode"><option value="seen">Marquer comme vus</option><option value="fav">Ajouter aux favoris</option><option value="both">Vus + favoris</option><option value="todo">Ajouter à « À regarder »</option></select><button class="btn" id="igo" style="background:var(--ac);color:#fff">Importer</button></div><div id="irep" style="margin-top:12px;font-size:13px"></div>`;
$("md").classList.add("show");
$("igo").onclick=async()=>{
const titles=[...new Set($("ita").value.split(/\n|;/).map(s=>s.replace(/^\s*(?:\d+[.)]|[-*•])\s*/,"").trim()).filter(Boolean))].slice(0,100);
const out=$("irep");if(!titles.length){out.textContent="Colle d’abord au moins un titre.";return}
const keys=$("imode").value==="both"?["seen","fav"]:[$("imode").value];
$("igo").disabled=true;const res=[];
try{for(let i=0;i<titles.length;i++){out.textContent="Recherche… "+(i+1)+"/"+titles.length;const a=await Sources.lookup(titles[i]);if(a)canon(a);res.push({t:titles[i],a})}}
catch(e){out.innerHTML=esc(e.message)+" Rien n’a été importé, tu peux réessayer.";$("igo").disabled=false;return}
const added=[];res.forEach(({a})=>{if(a)keys.forEach(k=>{if(!lib[k][a.id]){lib[k][a.id]=mini(a);added.push([k,a.id])}})});
W("lib",lib);refresh();
const ok=res.filter(r=>r.a),ko=res.filter(r=>!r.a);
out.innerHTML=`<b>${ok.length} trouvé${ok.length>1?"s":""} sur ${res.length}</b> · ${added.length} ajout${added.length>1?"s":""}<ul style="padding-left:18px;margin:8px 0">${ok.map(r=>`<li>${esc(r.t)} → <b>${esc(name(r.a))}</b></li>`).join("")}</ul>${ko.length?`<div style="color:#e5484d">Introuvables : ${ko.map(r=>esc(r.t)).join(", ")}</div>`:""}<p style="color:var(--mu)">Vérifie que chaque titre correspond bien à ce que tu voulais.</p><button class="btn" id="iun">↩ Annuler cet import</button>`;
$("iun").onclick=()=>{added.forEach(([k,id])=>delete lib[k][id]);W("lib",lib);refresh();out.textContent="Import annulé."};
$("igo").disabled=false}}
$("imp").onclick=openImport;
// sauvegarde / restauration
const OK=(()=>{try{localStorage.setItem("_t","1");const r=localStorage.getItem("_t")==="1";localStorage.removeItem("_t");return r}catch(e){return false}})();
if(!OK)$("warn").hidden=false;
const dump=()=>JSON.stringify({v:1,lib});
function openBackup(){
$("box").innerHTML=`<h2 style="margin:0 0 6px">💾 Sauvegarde</h2><p style="color:var(--mu);font-size:13px;margin:0 0 8px">${OK?"Tes listes sont enregistrées dans ce navigateur. Garde une sauvegarde pour les protéger ou les transférer sur un autre appareil.":"⚠️ Ce navigateur n’enregistre pas les données ici : sauvegarde tes listes et restaure-les à chaque ouverture."}</p><div class="row"><button class="btn" id="bdl">⬇ Télécharger le fichier</button><button class="btn" id="bcp">📋 Copier le code</button></div><p style="color:var(--mu);font-size:12px;margin:10px 0 4px">Code de sauvegarde (copie-le, ou colle ici un code pour restaurer) :</p><textarea id="bta" rows="4" style="width:100%;padding:10px;border-radius:10px;border:1px solid var(--bd);background:var(--bg);font-size:12px"></textarea><div class="row"><button class="btn" id="brs" style="background:var(--ac);color:#fff">Restaurer depuis le code</button><label class="btn">📂 Restaurer depuis un fichier<input type="file" id="bfi" accept=".json,application/json" hidden></label></div><div id="bmsg" style="margin-top:10px;font-size:13px"></div>`;
$("bta").value=dump();$("md").classList.add("show");
const restore=txt=>{try{const l=JSON.parse(txt).lib;if(!l||typeof l.fav!=="object"||typeof l.seen!=="object")throw 0;
lib.fav={...lib.fav,...l.fav};lib.seen={...lib.seen,...l.seen};lib.todo={...lib.todo,...(l.todo||{})};lib.prog={...lib.prog,...(l.prog||{})};
const ids=new Set(lib.hist.map(x=>x.id));lib.hist=[...lib.hist,...(Array.isArray(l.hist)?l.hist:[]).filter(x=>!ids.has(x.id))].slice(0,50);
W("lib",lib);refresh();$("bta").value=dump();$("bmsg").textContent="Restauré : "+Object.keys(lib.fav).length+" favoris, "+Object.keys(lib.seen).length+" vus."}
catch(e){$("bmsg").textContent="Code ou fichier invalide."}};
$("bdl").onclick=()=>{const u=URL.createObjectURL(new Blob([dump()],{type:"application/json"})),a=document.createElement("a");a.href=u;a.download="animedex-sauvegarde.json";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),2000)};
$("bcp").onclick=async()=>{const t=$("bta").value=dump();try{await navigator.clipboard.writeText(t);$("bmsg").textContent="Code copié."}catch(e){$("bta").select();$("bmsg").textContent="Sélectionne et copie le code ci-dessus."}};
$("brs").onclick=()=>restore($("bta").value);
$("bfi").onchange=async e=>{const f=e.target.files[0];if(f)restore(await f.text())}}
$("bk").onclick=openBackup;
// genres + démarrage
const GEN=["Action","Adventure","Comedy","Drama","Ecchi","Fantasy","Horror","Mecha","Music","Mystery","Psychological","Romance","Sci-Fi","Slice of Life","Sports","Supernatural","Thriller"];
function chips(){$("chips").innerHTML=GEN.map(g=>`<button class="chip${gsel.has(g)?" on":""}" data-g="${esc(g)}">${esc(g)}</button>`).join("")}
chips();updTabs();load(true);
// ===== Compte & synchronisation =====
const NATIVE=!!(window.Capacitor&&window.Capacitor.isNativePlatform&&window.Capacitor.isNativePlatform());
const SERVER="https://animedex-mk6owt0bu-iyadelyakchoues-projects.vercel.app";
const SRV=()=>SERVER;
let acc=S("acc",null),dirty=S("dirty",false),busy=false,quiet=false,ver=0,pt,msg="";
const nl=l=>migrate({fav:l.fav||{},seen:l.seen||{},todo:l.todo||{},prog:l.prog||{},hist:Array.isArray(l.hist)?l.hist:[]});
function mergeLib(a,b){a=nl(a);b=nl(b);const m={fav:{...b.fav,...a.fav},seen:{...b.seen,...a.seen},todo:{...b.todo,...a.todo},prog:{...b.prog}};
for(const[k,v]of Object.entries(a.prog))m.prog[k]=Math.max(v,m.prog[k]||0);
const ids=new Set();m.hist=[...a.hist,...b.hist].filter(x=>x&&!ids.has(x.id)&&ids.add(x.id)).slice(0,50);return m}
const saveLib=()=>{quiet=true;W("lib",lib);quiet=false};
function onLibChange(){if(quiet||!acc)return;ver++;dirty=true;W("dirty",true);label();clearTimeout(pt);pt=setTimeout(push,1500)}
async function api(p,o={}){try{const r=await fetch(SRV()+"/api/"+p,{method:o.method||"GET",headers:{"Content-Type":"application/json",...(acc&&o.auth!==false?{Authorization:"Bearer "+acc.token}:{})},body:o.body?JSON.stringify(o.body):undefined});let j={};try{j=await r.json()}catch(e){}
if(r.status===401&&acc&&o.auth!==false){setAcc(null);msg="Session expirée : reconnecte-toi."}return{status:r.status,ok:r.ok,j}}catch(e){return{status:0,ok:false,j:{error:"Serveur injoignable (hors ligne ?)."}}}}
function setAcc(a){acc=a;W("acc",a);label()}
function label(){$("ac").textContent=acc?"👤 "+acc.pseudo+(dirty?" ⟳":" ✓"):"👤 Compte"}
async function push(){if(!acc||busy)return;busy=true;
try{for(let i=0;i<3&&acc;i++){const v0=ver,r=await api("data",{method:"PUT",body:{baseRev:acc.rev,data:{lib}}});
if(r.status===409){lib=mergeLib(lib,(r.j.data||{}).lib||{});saveLib();acc.rev=r.j.rev;continue}
if(r.ok){acc.rev=r.j.rev;W("acc",acc);dirty=ver!==v0;W("dirty",dirty)}break}}
finally{busy=false;label();refresh()}}
async function pull(){if(!acc||busy||dirty)return;const r=await api("data");
if(r.ok&&r.j.data&&r.j.data.lib&&r.j.rev>acc.rev){lib=nl(r.j.data.lib);saveLib();acc.rev=r.j.rev;W("acc",acc);refresh()}label()}
async function first(){const r=await api("data");if(!r.ok)return;
if(r.j.data&&r.j.data.lib){lib=mergeLib(lib,r.j.data.lib);saveLib()}
acc.rev=r.j.rev;dirty=true;ver++;await push()}
async function logout(){if(dirty)await push();if(dirty&&!confirm("Des modifications n’ont pas pu être envoyées et seront perdues. Se déconnecter quand même ?"))return;
await api("logout",{method:"POST"});setAcc(null);lib={fav:{},seen:{},hist:[],todo:{},prog:{}};dirty=false;W("dirty",false);saveLib();refresh()}
const INP='style="width:100%;margin-bottom:8px;padding:10px;border-radius:10px;border:1px solid var(--bd);background:var(--bg)"';
function openAccount(){
if(!acc){$("box").innerHTML=`<h2 style="margin:0 0 6px">👤 Compte</h2><p style="color:var(--mu);font-size:13px;margin:0 0 10px">Crée un compte pour retrouver tes listes sur tous tes appareils : un pseudo et un mot de passe (8 caractères minimum). Il n’y a pas de récupération de mot de passe.</p><input id="apu" ${INP} placeholder="Pseudo" autocomplete="username" autocapitalize="off"><input id="app" ${INP} type="password" placeholder="Mot de passe" autocomplete="current-password"><div class="row"><button class="btn" id="alg" style="background:var(--ac);color:#fff">Se connecter</button><button class="btn" id="arg">Créer le compte</button></div><div id="amsg" style="margin-top:10px;font-size:13px">${esc(msg)}</div>`;msg="";
const go=async p=>{$("amsg").textContent="…";const r=await api(p,{method:"POST",auth:false,body:{pseudo:$("apu").value.trim(),password:$("app").value}});
if(!r.ok){$("amsg").textContent=r.j.error||"Erreur ("+r.status+").";return}
setAcc({token:r.j.token,pseudo:r.j.pseudo,rev:0});$("amsg").textContent="Synchronisation…";await first();openAccount()};
$("alg").onclick=()=>go("login");$("arg").onclick=()=>go("register");$("app").onkeydown=e=>{if(e.key==="Enter")go("login")}}
else{$("box").innerHTML=`<h2 style="margin:0 0 6px">👤 ${esc(acc.pseudo)}</h2><p style="color:var(--mu);font-size:13px">${dirty?"Modifications en attente de synchronisation.":"Tes listes sont synchronisées sur ce compte."}</p><div class="row"><button class="btn" id="asy">⟳ Synchroniser</button><button class="btn" id="alo">Se déconnecter</button></div><details style="margin-top:16px"><summary style="cursor:pointer;color:var(--mu);font-size:13px">Supprimer mon compte</summary><p style="font-size:13px">Supprime définitivement le compte et ses données sur le serveur.</p><input id="adp" ${INP} type="password" placeholder="Mot de passe" autocomplete="current-password"><button class="btn" id="adl" style="color:#e5484d">Supprimer définitivement</button></details><div id="amsg" style="margin-top:10px;font-size:13px">${esc(msg)}</div>`;msg="";
$("asy").onclick=async()=>{await push();await pull();openAccount()};
$("alo").onclick=async()=>{await logout();openAccount()};
$("adl").onclick=async()=>{const r=await api("account",{method:"DELETE",body:{password:$("adp").value}});if(!r.ok){$("amsg").textContent=r.j.error||"Erreur.";return}
setAcc(null);dirty=false;W("dirty",false);msg="Compte supprimé. Tes listes restent sur cet appareil.";openAccount()}}
$("md").classList.add("show")}
$("ac").onclick=openAccount;
label();if(acc)pull();
const tick=()=>{if(document.visibilityState==="visible")dirty?push():pull()};
document.addEventListener("visibilitychange",tick);addEventListener("online",tick);setInterval(tick,60000);
document.addEventListener("error",e=>{if(e.target.tagName==="IMG")e.target.style.visibility="hidden"},true);
if(!NATIVE&&"serviceWorker"in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("/sw.js").catch(()=>{});

